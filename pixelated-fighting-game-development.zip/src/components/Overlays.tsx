import { useEffect, useState } from "react";
import { loadScores, qualifies, saveScore, type ScoreEntry } from "../game/highscores";

const Btn = ({
  children,
  onClick,
  primary,
  small,
}: {
  children: React.ReactNode;
  onClick: () => void;
  primary?: boolean;
  small?: boolean;
}) => (
  <button
    type="button"
    onClick={onClick}
    className={`pixel-font touch-btn border-4 uppercase tracking-wider transition ${
      small ? "px-3 py-2 text-[9px]" : "px-6 py-3 text-xs sm:text-sm"
    } ${
      primary
        ? "border-yellow-200 bg-yellow-400 text-black shadow-[0_5px_0_#7a5a00] hover:bg-yellow-300"
        : "border-zinc-500 bg-zinc-800 text-zinc-100 shadow-[0_5px_0_#111] hover:bg-zinc-700"
    }`}
  >
    {children}
  </button>
);

export function ScoreTable({ list, highlight }: { list: ScoreEntry[]; highlight?: number }) {
  return (
    <div className="pixel-font w-full max-w-sm border-4 border-zinc-600 bg-black/80 p-3 text-[9px] sm:text-[10px]">
      <div className="mb-2 flex justify-between text-yellow-300">
        <span>RANK NAME</span>
        <span>WINS SCORE</span>
      </div>
      {list.length === 0 && <div className="py-3 text-center text-zinc-400">NO KOMBATANTS YET</div>}
      {list.map((e, i) => (
        <div
          key={`${e.date}-${i}`}
          className={`flex justify-between py-1 ${i === highlight ? "text-red-400 blink" : i === 0 ? "text-yellow-100" : "text-zinc-200"}`}
        >
          <span>
            {String(i + 1).padStart(2, "0")}. {e.name.padEnd(3, " ")}
          </span>
          <span>
            {String(e.wins).padStart(2, " ")} {String(e.score).padStart(7, "0")}
          </span>
        </div>
      ))}
    </div>
  );
}

export function StartScreen({
  onStart,
  isTouch,
  muted,
  onToggleMute,
}: {
  onStart: () => void;
  isTouch: boolean;
  muted: boolean;
  onToggleMute: () => void;
}) {
  const [showScores, setShowScores] = useState(false);
  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/60 p-4 text-center">
      <div className="slam-in">
        <h1 className="pixel-font text-3xl leading-tight text-yellow-400 drop-shadow-[4px_4px_0_#7a0000] sm:text-5xl">
          MORTAL
          <br />
          <span className="text-red-500">PIXEL</span> KOMBAT
        </h1>
      </div>
      <p className="pixel-font mt-4 text-[9px] text-zinc-300 sm:text-xs">CLIMB THE TOWER. FINISH THEM ALL.</p>

      {showScores ? (
        <div className="fade-up mt-5 flex flex-col items-center gap-4">
          <ScoreTable list={loadScores()} />
          <Btn onClick={() => setShowScores(false)} small>
            Back
          </Btn>
        </div>
      ) : (
        <>
          <div className="fade-up mt-6 flex flex-col items-center gap-3">
            <Btn onClick={onStart} primary>
              <span className="blink">{isTouch ? "Tap to Fight" : "Press Enter to Fight"}</span>
            </Btn>
            <div className="flex gap-2">
              <Btn onClick={() => setShowScores(true)} small>
                High Scores
              </Btn>
              <Btn onClick={onToggleMute} small>
                {muted ? "Sound: Off" : "Sound: On"}
              </Btn>
            </div>
          </div>
          <div className="pixel-font mt-6 grid max-w-md grid-cols-2 gap-x-6 gap-y-1 text-left text-[8px] leading-relaxed text-zinc-400 sm:text-[9px]">
            {isTouch ? (
              <>
                <span>STICK</span>
                <span className="text-zinc-200">MOVE / JUMP / CROUCH</span>
                <span>PUNCH + CROUCH</span>
                <span className="text-zinc-200">UPPERCUT</span>
                <span>KICK + CROUCH</span>
                <span className="text-zinc-200">SWEEP</span>
                <span>FIRE</span>
                <span className="text-zinc-200">FIREBALL</span>
              </>
            ) : (
              <>
                <span>WASD / ARROWS</span>
                <span className="text-zinc-200">MOVE JUMP CROUCH</span>
                <span>J / Z</span>
                <span className="text-zinc-200">PUNCH (DOWN = UPPERCUT)</span>
                <span>K / X</span>
                <span className="text-zinc-200">KICK (DOWN = SWEEP)</span>
                <span>L / C</span>
                <span className="text-zinc-200">FIREBALL</span>
                <span>SHIFT / V</span>
                <span className="text-zinc-200">BLOCK</span>
                <span>ESC / P</span>
                <span className="text-zinc-200">PAUSE</span>
              </>
            )}
          </div>
        </>
      )}
    </div>
  );
}

export function PauseScreen({
  onResume,
  onRestart,
  onQuit,
  muted,
  onToggleMute,
}: {
  onResume: () => void;
  onRestart: () => void;
  onQuit: () => void;
  muted: boolean;
  onToggleMute: () => void;
}) {
  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/70 p-4 text-center">
      <h2 className="pixel-font slam-in text-3xl text-yellow-400 drop-shadow-[3px_3px_0_#7a0000] sm:text-4xl">PAUSED</h2>
      <div className="fade-up mt-6 flex flex-col gap-3">
        <Btn onClick={onResume} primary>
          Resume
        </Btn>
        <Btn onClick={onRestart}>Restart</Btn>
        <Btn onClick={onToggleMute}>{muted ? "Sound: Off" : "Sound: On"}</Btn>
        <Btn onClick={onQuit}>Quit to Menu</Btn>
      </div>
    </div>
  );
}

export function GameOverScreen({
  score,
  wins,
  onRestart,
  onQuit,
  onSaved,
}: {
  score: number;
  wins: number;
  onRestart: () => void;
  onQuit: () => void;
  onSaved: () => void;
}) {
  const [name, setName] = useState("AAA");
  const [saved, setSaved] = useState<{ list: ScoreEntry[]; rank: number } | null>(null);
  const [canSave] = useState(() => qualifies(score));

  useEffect(() => {
    if (!canSave && !saved) setSaved({ list: loadScores(), rank: -1 });
  }, [canSave, saved]);

  const submit = () => {
    const n = (name.trim().toUpperCase() || "AAA").slice(0, 3);
    const res = saveScore({ name: n, score, wins, date: Date.now() });
    setSaved(res);
    onSaved();
  };

  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/75 p-4 text-center">
      <h2 className="pixel-font slam-in text-3xl text-red-500 drop-shadow-[3px_3px_0_#3a0000] sm:text-4xl">GAME OVER</h2>
      <div className="pixel-font fade-up mt-3 text-[10px] text-zinc-200 sm:text-xs">
        SCORE <span className="text-yellow-300">{String(score).padStart(7, "0")}</span> · TOWERS CLEARED{" "}
        <span className="text-yellow-300">{wins}</span>
      </div>

      {!saved && canSave && (
        <div className="fade-up mt-5 flex flex-col items-center gap-3">
          <div className="pixel-font text-[10px] text-yellow-300 blink">NEW HIGH SCORE! ENTER INITIALS</div>
          <div className="flex items-center gap-2">
            <input
              autoFocus
              value={name}
              maxLength={3}
              onChange={(e) => setName(e.target.value.replace(/[^a-zA-Z0-9]/g, "").toUpperCase())}
              onKeyDown={(e) => {
                if (e.key === "Enter") submit();
                e.stopPropagation();
              }}
              className="pixel-font w-28 border-4 border-yellow-300 bg-black px-3 py-2 text-center text-lg uppercase tracking-[0.4em] text-yellow-200 outline-none"
            />
            <Btn onClick={submit} primary small>
              Save
            </Btn>
          </div>
        </div>
      )}

      {saved && (
        <div className="fade-up mt-4 flex flex-col items-center gap-4">
          <ScoreTable list={saved.list} highlight={saved.rank >= 0 ? saved.rank : undefined} />
          <div className="flex gap-3">
            <Btn onClick={onRestart} primary>
              Fight Again
            </Btn>
            <Btn onClick={onQuit}>Menu</Btn>
          </div>
          <div className="pixel-font text-[8px] text-zinc-500">ENTER = INSTANT REMATCH</div>
        </div>
      )}
    </div>
  );
}
