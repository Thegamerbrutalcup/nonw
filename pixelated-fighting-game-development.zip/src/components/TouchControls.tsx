import { useCallback, useRef, useState } from "react";
import type { Action, Input } from "../game/input";

interface Props {
  input: Input;
}

const DEAD = 14;

export default function TouchControls({ input }: Props) {
  const padRef = useRef<HTMLDivElement>(null);
  const stickId = useRef<number | null>(null);
  const origin = useRef({ x: 0, y: 0 });
  const [knob, setKnob] = useState({ x: 0, y: 0, active: false });
  const [pressed, setPressed] = useState<Record<string, boolean>>({});

  const setDir = useCallback(
    (dx: number, dy: number) => {
      input.setTouch("left", dx < -DEAD);
      input.setTouch("right", dx > DEAD);
      input.setTouch("up", dy < -DEAD);
      input.setTouch("down", dy > DEAD);
    },
    [input]
  );

  const onPadDown = (e: React.PointerEvent) => {
    if (stickId.current !== null) return;
    stickId.current = e.pointerId;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    origin.current = { x: e.clientX, y: e.clientY };
    setKnob({ x: 0, y: 0, active: true });
  };
  const onPadMove = (e: React.PointerEvent) => {
    if (e.pointerId !== stickId.current) return;
    const dx = e.clientX - origin.current.x;
    const dy = e.clientY - origin.current.y;
    const len = Math.hypot(dx, dy);
    const max = 34;
    const k = len > max ? max / len : 1;
    setKnob({ x: dx * k, y: dy * k, active: true });
    setDir(dx, dy);
  };
  const onPadUp = (e: React.PointerEvent) => {
    if (e.pointerId !== stickId.current) return;
    stickId.current = null;
    setKnob({ x: 0, y: 0, active: false });
    setDir(0, 0);
  };

  const btn = (action: Action, label: string, cls: string) => {
    const down = (e: React.PointerEvent) => {
      e.preventDefault();
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
      input.setTouch(action, true);
      setPressed((p) => ({ ...p, [action]: true }));
    };
    const up = () => {
      input.setTouch(action, false);
      setPressed((p) => ({ ...p, [action]: false }));
    };
    return (
      <button
        type="button"
        onPointerDown={down}
        onPointerUp={up}
        onPointerCancel={up}
        onPointerLeave={(e) => {
          if (e.buttons === 0) return;
          up();
        }}
        onContextMenu={(e) => e.preventDefault()}
        className={`touch-btn pixel-font pointer-events-auto flex h-16 w-16 select-none items-center justify-center rounded-full border-4 text-[9px] leading-tight text-white shadow-[0_4px_0_rgba(0,0,0,0.6)] ${cls} ${
          pressed[action] ? "pressed brightness-150" : ""
        }`}
      >
        {label}
      </button>
    );
  };

  return (
    <div className="pointer-events-none absolute inset-0 z-20 select-none">
      {/* Virtual stick */}
      <div
        ref={padRef}
        onPointerDown={onPadDown}
        onPointerMove={onPadMove}
        onPointerUp={onPadUp}
        onPointerCancel={onPadUp}
        className="touch-btn pointer-events-auto absolute bottom-0 left-0 h-[46%] w-[42%] max-h-64"
        style={{ touchAction: "none" }}
      >
        <div
          className="absolute bottom-7 left-7 h-28 w-28 rounded-full border-4 border-white/25 bg-black/30"
          style={{ transform: "translate(0,0)" }}
        >
          <div
            className="absolute left-1/2 top-1/2 h-12 w-12 rounded-full border-4 border-white/50 bg-white/20"
            style={{
              transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))`,
              opacity: knob.active ? 1 : 0.6,
            }}
          />
          <span className="pixel-font absolute -top-4 left-1/2 -translate-x-1/2 text-[7px] text-white/50">JUMP</span>
          <span className="pixel-font absolute -bottom-4 left-1/2 -translate-x-1/2 text-[7px] text-white/50">CROUCH</span>
        </div>
      </div>

      {/* Action buttons */}
      <div className="absolute bottom-6 right-4 grid grid-cols-2 gap-3">
        {btn("punch", "PUNCH", "border-yellow-300 bg-yellow-500/70")}
        {btn("kick", "KICK", "border-red-300 bg-red-600/70")}
        {btn("block", "BLOCK", "border-sky-300 bg-sky-600/70")}
        {btn("special", "FIRE", "border-fuchsia-300 bg-fuchsia-600/70")}
      </div>
    </div>
  );
}
