import { useEffect, useRef, useState } from "react";
import { Engine, H, W, type UIState } from "./game/engine";
import { Input } from "./game/input";
import TouchControls from "./components/TouchControls";
import { GameOverScreen, PauseScreen, StartScreen } from "./components/Overlays";

const initialUI: UIState = {
  phase: "menu",
  paused: false,
  score: 0,
  level: 0,
  wins: 0,
  highScore: 0,
  muted: false,
  opponent: "",
  stage: "",
};

function detectTouch() {
  if (typeof window === "undefined") return false;
  return window.matchMedia?.("(pointer: coarse)").matches || "ontouchstart" in window;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const areaRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const inputRef = useRef<Input | null>(null);
  const [ui, setUi] = useState<UIState>(initialUI);
  const [size, setSize] = useState({ w: W * 2, h: H * 2 });
  const [isTouch, setIsTouch] = useState(detectTouch);
  const [portrait, setPortrait] = useState(() => (typeof window !== "undefined" ? window.innerHeight > window.innerWidth : false));
  const [ready, setReady] = useState(false);

  // Engine lifecycle
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const input = new Input();
    input.attach();
    inputRef.current = input;
    const engine = new Engine(canvas, input);
    engine.onUI = (s) => setUi({ ...s });
    engineRef.current = engine;

    const boot = () => {
      engine.start();
      setReady(true);
    };
    if (document.fonts?.load) {
      Promise.all([document.fonts.load('8px "Press Start 2P"'), document.fonts.load('16px "Press Start 2P"')])
        .then(boot)
        .catch(boot);
      // Failsafe if fonts never resolve
      setTimeout(() => {
        if (!ready) boot();
      }, 1500);
    } else boot();

    const onTouch = () => setIsTouch(true);
    window.addEventListener("touchstart", onTouch, { once: true, passive: true });
    const onVis = () => {
      if (document.hidden && engine.phase !== "menu" && engine.phase !== "gameover" && !engine.paused) engine.togglePause();
    };
    document.addEventListener("visibilitychange", onVis);

    return () => {
      engine.stop();
      input.detach();
      window.removeEventListener("touchstart", onTouch);
      document.removeEventListener("visibilitychange", onVis);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Responsive canvas sizing
  useEffect(() => {
    const area = areaRef.current;
    if (!area) return;
    const measure = () => {
      const r = area.getBoundingClientRect();
      const pad = 8;
      const aw = Math.max(64, r.width - pad);
      const ah = Math.max(36, r.height - pad);
      let scale = Math.min(aw / W, ah / H);
      // Prefer integer scale when it doesn't waste too much space
      if (scale >= 2 && Math.floor(scale) / scale > 0.8) scale = Math.floor(scale);
      setSize({ w: Math.floor(W * scale), h: Math.floor(H * scale) });
      setPortrait(window.innerHeight > window.innerWidth);
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(area);
    window.addEventListener("resize", measure);
    window.addEventListener("orientationchange", measure);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", measure);
      window.removeEventListener("orientationchange", measure);
    };
  }, [isTouch, portrait]);

  const engine = engineRef.current;
  const inGame = ui.phase !== "menu" && ui.phase !== "gameover";
  const showTouch = isTouch && (inGame || ui.phase === "gameover");

  return (
    <div className="relative flex h-full w-full flex-col bg-[#0a0508] text-white">
      {/* Canvas area */}
      <div ref={areaRef} className="relative flex min-h-0 flex-1 items-center justify-center">
        <div className="scanlines relative shadow-[0_0_60px_rgba(255,60,60,0.15)]" style={{ width: size.w, height: size.h }}>
          <canvas
            ref={canvasRef}
            className="pixelated block bg-black"
            style={{ width: size.w, height: size.h }}
            onClick={() => {
              if (engine?.phase === "menu") engine.newGame();
            }}
          />
          {!ready && (
            <div className="pixel-font absolute inset-0 flex items-center justify-center bg-black text-xs text-yellow-300">LOADING...</div>
          )}

          {ready && ui.phase === "menu" && engine && (
            <StartScreen
              onStart={() => engine.newGame()}
              isTouch={isTouch}
              muted={ui.muted}
              onToggleMute={() => engine.toggleMute()}
            />
          )}

          {ui.paused && inGame && engine && (
            <PauseScreen
              onResume={() => engine.togglePause()}
              onRestart={() => engine.newGame()}
              onQuit={() => engine.quitToMenu()}
              muted={ui.muted}
              onToggleMute={() => engine.toggleMute()}
            />
          )}

          {ui.phase === "gameover" && engine && (
            <GameOverScreen
              key={ui.score + "-" + ui.level}
              score={ui.score}
              wins={ui.wins}
              onRestart={() => engine.newGame()}
              onQuit={() => engine.quitToMenu()}
              onSaved={() => engine.refreshHighScore()}
            />
          )}

          {/* In-game corner buttons */}
          {inGame && !ui.paused && engine && (
            <button
              type="button"
              onClick={() => engine.togglePause()}
              className="pixel-font touch-btn absolute right-1 top-1 z-20 border-2 border-white/30 bg-black/50 px-2 py-1 text-[8px] text-white/80"
            >
              II
            </button>
          )}
        </div>
      </div>

      {/* Reserve space for the touch controls in portrait */}
      {showTouch && portrait && <div className="h-52 shrink-0" />}

      {showTouch && inputRef.current && <TouchControls input={inputRef.current} />}
    </div>
  );
}
